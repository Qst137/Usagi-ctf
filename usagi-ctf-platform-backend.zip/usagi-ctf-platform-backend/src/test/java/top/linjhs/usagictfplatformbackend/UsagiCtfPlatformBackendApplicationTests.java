package top.linjhs.usagictfplatformbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsagiCtfPlatformBackendApplicationTests {

    @Test
    void contextLoads() {
    }

    @Test
    void testDocker(){

    }

}
